<?php
// ** reglages MySQL ** //
define('WP_CACHE', true); //Added by WP-Cache Manager
define('DB_NAME', 'neufboxsql');    // Le nom de la base de donnees
define('DB_USER', 'neufboxsql');     // Votre identifiant MySQL
define('DB_PASSWORD', 'kw4msgbn'); // ...et votre mot de passe
define('DB_HOST', 'mysql5-4');    // Dans la plupart des cas, vous n'aurez pas a modifier cette ligne
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', '');

// Modifier SECRET_KEY par une phrase unique.  Vous n'avez pas besoin de la mémoriser pour plus tard.
// Elle doit être longue et complique.  Vous pouvez aller sur le site https://www.grc.com/passwords.htm
// afin de générer une phrase unique pour votre installation.
define('SECRET_KEY', '5bMjayWCDYC1Vjsie8SzifO0E65aj9gsKALmIsY4EVc5DUi1OOyE62JAGVsYVYO'); // Modifier par une phrase unique. 

// Vous pouvez faire plusieurs installation sur une même base de données en leur donnant un préfixe unique
$table_prefix  = 'wp_';		// Que des chiffres, lettres ou soulignés, s'il vous plait !

// Modifiez la ligne suivante pour traduire WordPress. Il faut que le dossier
// wp-content/languages contienne un fichier .mo correspondant à la langue choisir.
// Par exemple,  installer de.mo dans wp-content/languages et préciser 'de' à WPLANG
// pour mettre en place la traduction allemande.
define ('WPLANG', 'fr_FR');

/* C'est tout, ne touchez pas au reste ! Bloguez bien ! */

define('ABSPATH', dirname(__FILE__).'/');
require_once(ABSPATH.'wp-settings.php');
?>
