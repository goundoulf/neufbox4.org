<?php

if (! isset($wp_did_header)):
  if ( !file_exists( dirname(__FILE__) . '/wp-config.php') ) {
  	if (strpos($_SERVER['PHP_SELF'], 'wp-admin') !== false) $path = '';
  	else $path = 'wp-admin/';
  
  	require_once( dirname(__FILE__) . '/wp-includes/classes.php');
  	require_once( dirname(__FILE__) . '/wp-includes/functions.php');
  	require_once( dirname(__FILE__) . '/wp-includes/plugin.php');
  	wp_die("<p>Je ne trouve pas votre fichier <code>wp-config.php</code>. J'en ai besoin avant de lancer l'installation.<br />Besoin d'aide ? <a href='http://codex.wordpress.org/fr:Installer_WordPress'>En voici</a>.</p><p>Vous pouvez cr&eacute;er un fichier <code>wp-config.php</code> &agrave; l'aide de notre interface Web, mais &ccedil;a ne marche pas pour toutes les configurations de serveur. La m&eacute;thode la plus s&ucirc;re reste de cr&eacute;er le fichier &agrave; la main.</p><p><a href='{$path}setup-config.php' class='button'>Cr&eacute;er le fichier de configuration</a></p>", "WordPress &rsaquo; Erreur");
  }
  
  $wp_did_header = true;
  require_once( dirname(__FILE__) . '/wp-config.php');
  wp();
  require_once(ABSPATH . WPINC . '/template-loader.php');
endif;
?>